// POST /api/create-checkout-session
// Receives { tier, customerEmail } and returns a Stripe Checkout URL to redirect the user to.
// Stripe Checkout automatically offers card, Apple Pay, and Google Pay on supported devices/browsers
// as long as those payment methods are turned on in your Stripe Dashboard (Settings -> Payment methods).

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Create these as recurring Prices in your Stripe Dashboard (Product catalog -> Add product),
// then paste each Price ID into your environment variables.
const PRICE_IDS = {
  starter: process.env.STRIPE_PRICE_STARTER,
  pro: process.env.STRIPE_PRICE_PRO,
  ultra: process.env.STRIPE_PRICE_ULTRA
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  if (!process.env.STRIPE_SECRET_KEY) {
    return res.status(500).json({ error: 'Server is missing STRIPE_SECRET_KEY.' });
  }

  const { tier, customerEmail } = req.body || {};
  const priceId = PRICE_IDS[tier];
  if (!priceId) {
    return res.status(400).json({ error: `No Stripe price configured for tier "${tier}". Set STRIPE_PRICE_${String(tier).toUpperCase()} in your environment variables.` });
  }

  const publicUrl = process.env.PUBLIC_URL || `https://${req.headers.host}`;

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: priceId, quantity: 1 }],
      customer_email: customerEmail || undefined,
      metadata: { tier },
      success_url: `${publicUrl}/?checkout=success&tier=${tier}`,
      cancel_url: `${publicUrl}/?checkout=cancelled`
    });
    return res.status(200).json({ url: session.url });
  } catch (err) {
    console.error('Peacho /api/create-checkout-session error:', err);
    return res.status(500).json({ error: err.message });
  }
}
