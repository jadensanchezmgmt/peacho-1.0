// POST /api/webhook
// Stripe calls this URL directly whenever a payment or subscription event happens.
// This is how your app finds out someone subscribed, upgraded, or cancelled -
// it does NOT rely on the user's browser being open.
//
// IMPORTANT: this file currently only logs events. To actually remember who is
// subscribed, connect a database (Supabase, Firebase, etc.) and, in the marked
// spots below, write the customer's email + tier to a users table. Your app's
// sign-in flow should then look up tier from that table instead of local storage.

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export const config = {
  api: { bodyParser: false } // Stripe needs the raw request body to verify the signature
};

async function buffer(readable) {
  const chunks = [];
  for await (const chunk of readable) {
    chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
  }
  return Buffer.concat(chunks);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const sig = req.headers['stripe-signature'];
  const buf = await buffer(req);

  let event;
  try {
    event = stripe.webhooks.constructEvent(buf, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Peacho webhook signature error:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const email = session.customer_email;
      const tier = session.metadata && session.metadata.tier;
      console.log(`Peacho: ${email} subscribed to ${tier}`);
      // TODO: save { email, tier, stripeCustomerId: session.customer } to your database
      break;
    }
    case 'customer.subscription.deleted': {
      const subscription = event.data.object;
      console.log(`Peacho: subscription ${subscription.id} was cancelled`);
      // TODO: find the user by subscription.customer and set their tier to null in your database
      break;
    }
    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      console.log(`Peacho: payment failed for customer ${invoice.customer}`);
      // TODO: optionally email the user or flag their account
      break;
    }
    default:
      break;
  }

  res.status(200).json({ received: true });
}
