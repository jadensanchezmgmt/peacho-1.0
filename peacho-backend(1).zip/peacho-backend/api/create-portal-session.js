// POST /api/create-portal-session
// Lets an already-subscribed user open Stripe's hosted page to update their card,
// change tier, or cancel - so you don't have to build that UI yourself.
// Requires you to have stored the Stripe customerId for the user (see webhook.js TODOs).

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { customerId } = req.body || {};
  if (!customerId) {
    return res.status(400).json({ error: 'Missing customerId - look this up from your database using the signed-in user\'s email.' });
  }

  const publicUrl = process.env.PUBLIC_URL || `https://${req.headers.host}`;

  try {
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${publicUrl}/`
    });
    return res.status(200).json({ url: session.url });
  } catch (err) {
    console.error('Peacho /api/create-portal-session error:', err);
    return res.status(500).json({ error: err.message });
  }
}
