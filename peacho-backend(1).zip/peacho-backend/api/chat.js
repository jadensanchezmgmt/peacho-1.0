// POST /api/chat
// Receives { messages, system, max_tokens } from the Peacho frontend,
// adds the real Anthropic API key (kept only on the server), and returns Claude's reply.
// This is the piece that makes chat, image, and animation generation work once deployed.

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: { message: 'Method not allowed' } });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: { message: 'Server is missing ANTHROPIC_API_KEY. Add it in your hosting provider\'s environment variables.' } });
  }

  const { messages, system, max_tokens } = req.body || {};
  if (!messages) {
    return res.status(400).json({ error: { message: 'Missing messages in request body' } });
  }

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-5-5',
        max_tokens: max_tokens || 1000,
        system,
        messages
      })
    });
    const data = await upstream.json();
    return res.status(upstream.status).json(data);
  } catch (err) {
    console.error('Peacho /api/chat error:', err);
    return res.status(500).json({ error: { message: 'Could not reach Anthropic API' } });
  }
}
