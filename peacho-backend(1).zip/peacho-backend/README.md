# Peacho backend

This turns Peacho from a preview into a real, deployable app. It has three jobs:

1. `/api/chat` — holds your Anthropic API key and talks to Claude on the frontend's behalf.
2. `/api/create-checkout-session` — starts a real Stripe payment (card, Apple Pay, Google Pay).
3. `/api/webhook` and `/api/create-portal-session` — tell your app when someone subscribes, cancels, or wants to manage billing.

The frontend (`public/index.html`) already calls these endpoints. If it can't reach them (e.g. you're just previewing the file locally without deploying), it quietly falls back to a local demo mode so nothing breaks.

## 1. Get your keys

- **Anthropic**: console.anthropic.com → API Keys → create one.
- **Stripe**: dashboard.stripe.com → sign up, verify your identity, add your bank account under Settings → Bank accounts (this is where payouts land).
- **Stripe Prices**: dashboard.stripe.com → Product catalog → create three products (Starter $15/mo, Pro $29/mo, Ultra $49/mo), each as a **recurring monthly** price. Copy each Price ID.
- **Stripe webhook secret**: you'll get this in step 4, after deploying.

## 2. Fill in your environment variables

Copy `.env.example` to `.env` and fill in the values you just collected. Do not commit `.env` to any public repo.

## 3. Deploy (Vercel is the easiest path)

```bash
npm install -g vercel
cd peacho-backend
vercel
```

Follow the prompts to link/create a project. Then add every variable from `.env` in the Vercel dashboard under Settings → Environment Variables, and redeploy:

```bash
vercel --prod
```

You'll get a live URL like `https://peacho-yourname.vercel.app`. That's your app, working for real.

## 4. Connect the Stripe webhook

In dashboard.stripe.com → Developers → Webhooks → Add endpoint:
- URL: `https://your-deployed-url.vercel.app/api/webhook`
- Events to send: `checkout.session.completed`, `customer.subscription.deleted`, `invoice.payment_failed`

Copy the signing secret it gives you into `STRIPE_WEBHOOK_SECRET` in Vercel, then redeploy.

## 5. Connect your domain

In Vercel → Settings → Domains, add the domain you bought and follow the DNS instructions your registrar gives you. Once it's live, set `PUBLIC_URL` to your real domain and redeploy.

## What's still on you (important)

- **Remembering who's subscribed across devices/browsers** needs a real database (Supabase and Firebase both have easy free tiers). Right now, `api/webhook.js` has clearly marked `// TODO` comments showing exactly where to save a subscriber's email + tier — wire that to a database, then have your sign-in flow look up tier from there instead of the browser's local storage.
- **Google/Facebook sign-in** needs you to register an app with Google Cloud Console / Meta for Developers and add your live domain as the redirect URI.
- **Testing payments safely**: use your Stripe **test mode** keys (they start with `sk_test_`) and Stripe's test card `4242 4242 4242 4242` until you're confident everything works, then switch to live keys.
